class Chatbot:
    def __init__(self):
        self.name = 'AI Chatbot'

    def respond(self, message):
        return f'Response to "{message}"'