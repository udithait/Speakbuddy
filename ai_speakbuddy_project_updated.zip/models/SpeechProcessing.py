class SpeechProcessing:
    def __init__(self):
        pass

    def text_to_speech(self, text):
        return f'Converting "{text}" to speech'

    def speech_to_text(self, audio):
        return 'Converted speech to text'