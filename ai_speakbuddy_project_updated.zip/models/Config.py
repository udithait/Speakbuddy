class Config:
    DEBUG = True
    DATABASE_URL = 'sqlite:///:memory:'