class Utils:
    @staticmethod
    def format_text(text):
        return text.strip().capitalize()